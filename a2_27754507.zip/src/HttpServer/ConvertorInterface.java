package HttpServer;

public interface ConvertorInterface {

	public String translate(String str);
	
}
